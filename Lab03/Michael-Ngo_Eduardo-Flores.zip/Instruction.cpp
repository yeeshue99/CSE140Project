#include <iostream>
#include "Instruction.h"

void Instruction::print(){
    std::cout << "Instruction!" << std::endl;
}
