#ifndef INSTRUCTION_H
#define INSTRUCTION_H


class Instruction {
    public:
        void print();
};

#endif