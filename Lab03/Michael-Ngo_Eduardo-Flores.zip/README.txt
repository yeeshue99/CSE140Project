Place binary mips instructions in input.txt.
Each instruction must be separated onto a new line.

This project needs to be run on linux OS, or using with an extension that allows the use of make
In order to run, simply do make run.
